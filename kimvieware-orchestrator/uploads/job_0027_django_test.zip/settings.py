
DEBUG = True
SECRET_KEY = 'test-key'
INSTALLED_APPS = []
