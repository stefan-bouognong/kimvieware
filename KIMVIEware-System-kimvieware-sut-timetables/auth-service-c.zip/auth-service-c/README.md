# Auth Service (C)

Authentication service implemented in C for symbolic execution testing.

## Features
- Username validation (10+ branches)
- Password strength validation (15+ branches)
- User authentication (20+ branches)
- User registration (15+ branches)
- Password change (10+ branches)

**Total: ~70 branches → 100+ paths with symbolic execution**

## Build
```bash
make
```

## Run
```bash
./auth_service
```

## Expected Paths
- Symbolic execution should extract 80-120 execution paths
- Demonstrates path explosion in C code
